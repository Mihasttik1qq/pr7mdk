﻿using System;
using System.Collections.Generic;

namespace WpfApp3;

public partial class Job
{
    public int IdJobTitle { get; set; }

    public string JobTitle { get; set; } = null!;

    public virtual ICollection<Prepod> Prepods { get; set; } = new List<Prepod>();
}
