﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;

namespace WpfApp3
{
    public partial class MainWindow : Window
    {
        private AllPrepodContext db = new AllPrepodContext();

        public MainWindow()
        {
            InitializeComponent();

            CmbFiltr.ItemsSource = db.Jobs.ToList();
            CmbFiltr.DisplayMemberPath = "JobTitle";
            CmbFiltr.SelectedValuePath = "IdJobTitle";

            LoadData();
        }

        private void LoadData()
        {
            var prepods = db.Prepods.Include(p => p.IdJobTitleNavigation).ToList();
            DtgPrepods.ItemsSource = prepods;
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            string searchText = TxtSearch.Text.Trim();

            var results = db.Prepods
                .Include(p => p.IdJobTitleNavigation)
                .Where(p => p.Name.Contains(searchText))
                .ToList();

            DtgPrepods.ItemsSource = results;

            if (results.Count == 0)
            {
                MessageBox.Show("Преподаватель не найден");
            }
        }

        private void BtnSortUp_Click(object sender, RoutedEventArgs e)
        {
            var sorted = db.Prepods.Include(p => p.IdJobTitleNavigation)
                .OrderBy(p => p.zarplata).ToList();
            DtgPrepods.ItemsSource = sorted;
        }

        private void BtnSortDown_Click(object sender, RoutedEventArgs e)
        {
            var sorted = db.Prepods.Include(p => p.IdJobTitleNavigation)
                .OrderByDescending(p => p.zarplata).ToList();
            DtgPrepods.ItemsSource = sorted;
        }

        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbFiltr.SelectedValue != null)
            {
                int selectedJobId = (int)CmbFiltr.SelectedValue;

                var filtered = db.Prepods.Include(p => p.IdJobTitleNavigation)
                    .Where(p => p.IdJobTitle == selectedJobId)
                    .ToList();

                DtgPrepods.ItemsSource = filtered;
            }
        }
    }
}
