﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace WpfApp3;

public partial class AllPrepodContext : DbContext
{
    public AllPrepodContext()
    {
    }

    public AllPrepodContext(DbContextOptions<AllPrepodContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Department> Departments { get; set; }

    public virtual DbSet<Job> Jobs { get; set; }

    public virtual DbSet<Prepod> Prepods { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
       protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    => optionsBuilder.UseSqlite("Data Source=C:\\Users\\Студент.44-4\\Desktop\\Prepodavateli.db");
    {





        modelBuilder.Entity<Department>(entity =>
        {
            entity.HasKey(e => e.IdDepartment);

            entity.ToTable("Department");

            entity.HasIndex(e => e.IdDepartment, "IX_Department_IdDepartment").IsUnique();

            entity.Property(e => e.Departament).HasColumnName("departament");
        });

        modelBuilder.Entity<Prepod>(entity =>
        {
            entity.HasKey(e => e.IdPrepod);

            entity.ToTable("Prepod");

            entity.HasIndex(e => e.IdPrepod, "IX_Prepod_IdPrepod").IsUnique();

            entity.Property(e => e.zarplata).HasColumnName("zarplata");

            entity.HasOne(d => d.IdJobTitleNavigation)
                .WithMany(p => p.Prepods)
                .HasForeignKey(d => d.IdJobTitle);
        });

        modelBuilder.Entity<Job>(entity =>
        {
            entity.HasKey(e => e.IdJobTitle);

            entity.ToTable("Job");

            entity.HasIndex(e => e.IdJobTitle, "IX_Job_IdJobTitle").IsUnique();
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
