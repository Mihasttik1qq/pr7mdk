﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace WpfApp3
{
    public partial class PrepodavateliContext : DbContext
    {
        public PrepodavateliContext()
        {
        }

        public PrepodavateliContext(DbContextOptions<PrepodavateliContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Department> Departments { get; set; }
        public virtual DbSet<Job> Jobs { get; set; }
        public virtual DbSet<Prepod> Prepods { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See https://go.microsoft.com/fwlink/?linkid=2131148.
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlite("Data Source = D:\\Prepodavateli.db");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Department>(entity =>
            {
                entity.HasKey(e => e.IdDepartment);

                entity.ToTable("Department");

                entity.HasIndex(e => e.IdDepartment, "IX_Department_IdDepartment").IsUnique();

                entity.Property(e => e.Departament).HasColumnName("departament");
            });

            modelBuilder.Entity<Prepod>(entity =>
            {
                entity.HasKey(e => e.IdPrepod);

                entity.ToTable("Prepod");

                entity.HasIndex(e => e.IdPrepod, "IX_Prepod_IdPrepod").IsUnique();

                entity.Property(e => e.zarplata).HasColumnName("zarplata");

                entity.HasOne(d => d.IdJobTitleNavigation)
                    .WithMany(p => p.Prepods)
                    .HasForeignKey(d => d.IdJobTitle);
            });

            modelBuilder.Entity<Job>(entity =>
            {
                entity.HasKey(e => e.IdJobTitle);

                entity.ToTable("Job");

                entity.HasIndex(e => e.IdJobTitle, "IX_Job_IdJobTitle").IsUnique();
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
