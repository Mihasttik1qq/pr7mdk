﻿using System.Windows;
using System.Linq;

namespace WpfApp3
{
    public partial class AddWindow : Window
    {
        private PrepodavateliContext _context = new PrepodavateliContext();
        public Prepod NewPrepod { get; private set; }

        public AddWindow()
        {
            InitializeComponent();
            CmbJob.ItemsSource = _context.Jobs.ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtName.Text) || string.IsNullOrWhiteSpace(TxtSalary.Text) || CmbJob.SelectedValue == null)
            {
                MessageBox.Show("Заполните все поля.");
                return;
            }

            if (!decimal.TryParse(TxtSalary.Text, out decimal salary))
            {
                MessageBox.Show("Введите корректную зарплату.");
                return;
            }

            NewPrepod = new Prepod
            {
                Name = TxtName.Text.Trim(),
                zarplata = salary,
                IdJobTitle = (int)CmbJob.SelectedValue
            };

            DialogResult = true;
        }
    }
}
