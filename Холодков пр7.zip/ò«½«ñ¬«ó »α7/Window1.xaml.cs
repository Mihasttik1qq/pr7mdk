﻿using System.Windows;
using System.Linq;

namespace WpfApp3
{
    public partial class EditWindow : Window
    {
        private Prepod _prepod;
        private PrepodavateliContext _context = new PrepodavateliContext();

        public EditWindow(Prepod prepod)
        {
            InitializeComponent();
            _prepod = prepod;

            CmbJob.ItemsSource = _context.Jobs.ToList();
            CmbJob.SelectedValue = prepod.IdJobTitle;

            TxtName.Text = prepod.Name;
            TxtSalary.Text = prepod.zarplata.ToString();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            _prepod.Name = TxtName.Text;

            if (decimal.TryParse(TxtSalary.Text, out decimal salary))
            {
                _prepod.zarplata = salary;
            }

            _prepod.IdJobTitle = (int)CmbJob.SelectedValue;
            DialogResult = true;
        }
    }
}
