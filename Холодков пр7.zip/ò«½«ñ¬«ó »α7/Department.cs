﻿using System;
using System.Collections.Generic;

namespace WpfApp3;

public partial class Department
{
    public int IdDepartment { get; set; }

    public string Departament { get; set; } = null!;
}
