﻿using System;
using System.Collections.Generic;

namespace WpfApp3;

public partial class Prepod
{
    public int IdPrepod { get; set; }

    public string Name { get; set; } = null!;

    public int? IdJobTitle { get; set; }

    public int? IdDepartment { get; set; }

    public double zarplata { get; set; }

    public virtual Job? IdJobTitleNavigation { get; set; }
}
