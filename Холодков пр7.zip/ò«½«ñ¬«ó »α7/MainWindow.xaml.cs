﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;

namespace WpfApp3
{
    public partial class MainWindow : Window
    {
        private PrepodavateliContext db = new PrepodavateliContext();

        public MainWindow()
        {
            InitializeComponent();

            CmbFiltr.ItemsSource = db.Jobs.ToList();
            CmbFiltr.DisplayMemberPath = "JobTitle";
            CmbFiltr.SelectedValuePath = "IdJobTitle";

            LoadData();
        }

        private void LoadData()
        {
            var prepods = db.Prepods.Include(p => p.IdJobTitleNavigation).ToList();
            DtgPrepods.ItemsSource = prepods;
            UpdateCounter(prepods.Count);
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            string searchText = TxtSearch.Text.Trim();

            var results = db.Prepods
                .Include(p => p.IdJobTitleNavigation)
                .Where(p => p.Name.Contains(searchText))
                .ToList();

            DtgPrepods.ItemsSource = results;
            UpdateCounter(results.Count);

            if (results.Count == 0)
            {
                MessageBox.Show("Преподаватель не найден");
            }
        }

        private void BtnSortUp_Click(object sender, RoutedEventArgs e)
        {
            var sorted = db.Prepods.Include(p => p.IdJobTitleNavigation)
                .OrderBy(p => p.zarplata).ToList();
            DtgPrepods.ItemsSource = sorted;
            UpdateCounter(sorted.Count);
        }

        private void BtnSortDown_Click(object sender, RoutedEventArgs e)
        {
            var sorted = db.Prepods.Include(p => p.IdJobTitleNavigation)
                .OrderByDescending(p => p.zarplata).ToList();
            DtgPrepods.ItemsSource = sorted;
            UpdateCounter(sorted.Count);
        }

        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbFiltr.SelectedValue != null)
            {
                int selectedJobId = (int)CmbFiltr.SelectedValue;

                var filtered = db.Prepods.Include(p => p.IdJobTitleNavigation)
                    .Where(p => p.IdJobTitle == selectedJobId)
                    .ToList();

                DtgPrepods.ItemsSource = filtered;
                UpdateCounter(filtered.Count);
            }
        }

        private void BtnStats_Click(object sender, RoutedEventArgs e)
        {
            StatsWindow statsWindow = new StatsWindow();
            statsWindow.Owner = this;
            statsWindow.ShowDialog();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            var selected = DtgPrepods.SelectedItem as Prepod;
            if (selected == null)
            {
                MessageBox.Show("Выберите преподавателя для редактирования.");
                return;
            }

            EditWindow editWindow = new EditWindow(selected);
            editWindow.Owner = this;
            if (editWindow.ShowDialog() == true)
            {
                db.Entry(selected).State = EntityState.Modified;
                db.SaveChanges();
                LoadData();
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var selected = DtgPrepods.SelectedItem as Prepod;
            if (selected == null)
            {
                MessageBox.Show("Выберите преподавателя для удаления.");
                return;
            }

            var result = MessageBox.Show($"Удалить преподавателя {selected.Name}?",
                                         "Подтверждение удаления",
                                         MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes)
            {
                db.Prepods.Remove(selected);
                db.SaveChanges();
                LoadData();
            }
        }
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            AddWindow addWindow = new AddWindow();
            addWindow.Owner = this;
            if (addWindow.ShowDialog() == true)
            {
                db.Prepods.Add(addWindow.NewPrepod);
                db.SaveChanges();
                LoadData();
            }
        }


        private void UpdateCounter(int count)
        {
            TxtCounter.Text = $"Количество преподавателей: {count}";
        }
    }
}
