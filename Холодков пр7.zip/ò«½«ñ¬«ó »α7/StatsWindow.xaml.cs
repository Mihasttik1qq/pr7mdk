﻿using System.Linq;
using System.Windows;

namespace WpfApp3
{
    public partial class StatsWindow : Window
    {
        public StatsWindow()
        {
            InitializeComponent();

            using (var db = new PrepodavateliContext())
            {
                var salaries = db.Prepods.Select(p => p.zarplata).ToList();

                if (salaries.Any())
                {
                    TxtSum.Text = $"Сумма зарплат: {salaries.Sum():N2} ₽";
                    TxtAvg.Text = $"Средняя зарплата: {salaries.Average():N2} ₽";
                    TxtMin.Text = $"Минимальная зарплата: {salaries.Min():N2} ₽";
                    TxtMax.Text = $"Максимальная зарплата: {salaries.Max():N2} ₽";
                }
                else
                {
                    TxtSum.Text = "Нет данных о зарплатах.";
                }
            }
        }
    }
}
